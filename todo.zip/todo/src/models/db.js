const User = require("./user");
const Task = require("./task");

module.exports = {
    User,
    Task
};

